import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import "./App.css";

import forest from "./assets/forest.jpg";
import storyBg from "./assets/story-bg.jpeg";

import haldi1 from "./assets/haldi/haldi-1.jpg.jpg";
import haldi2 from "./assets/haldi/Haldi-2.jpg.jpg";

import wedding1 from "./assets/wedding/wedding-1.jpg.jpg";
import wedding2 from "./assets/wedding/wedding-2.jpg.jpg";

import reception2 from "./assets/reception/reception-2.jpg.jpg";
import reception3 from "./assets/reception/reception-3.jpg.jpg";

gsap.registerPlugin(ScrollTrigger);

function App() {
  const heroRef = useRef(null);
  const forestLayerRef = useRef(null);
  const glowRef = useRef(null);
  const particlesRef = useRef(null);
  const overlayRef = useRef(null);
  const scrollHintRef = useRef(null);
  const progressFillRef = useRef(null);
  const eventCardsRef = useRef([]);

  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {

      /* =================================
         HERO ANIMATION
      ================================= */

      const particles =
        particlesRef.current.querySelectorAll("span");

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: heroRef.current,
          start: "top top",
          end: "+=120%",
          scrub: 1,
          pin: true,
        },
      });

      tl.to(
        progressFillRef.current,
        {
          width: "100%",
          ease: "none",
        },
        0
      );

      tl.to(
        scrollHintRef.current,
        {
          opacity: 0,
          y: 20,
          duration: 0.1,
        },
        0
      );

      tl.to(
        forestLayerRef.current,
        {
          scale: 1.15,
          ease: "power1.inOut",
        },
        0
      );

      particles.forEach((p) => {
        const rect = p.getBoundingClientRect();

        const centerX = window.innerWidth / 2;
        const centerY = window.innerHeight * 0.48;

        tl.to(
          p,
          {
            x:
              centerX -
              rect.left -
              rect.width / 2,

            y:
              centerY -
              rect.top -
              rect.height / 2,

            scale: 0.3,
            opacity: 0,

            ease: "power2.in",
          },
          0
        );
      });

      tl.to(
        glowRef.current,
        {
          scale: 0.4,
          opacity: 1,
          filter: "blur(8px)",
          ease: "power2.inOut",
        },
        0.15
      );

      tl.to(
        overlayRef.current,
        {
          opacity: 1,

          background:
            "radial-gradient(circle at 50% 48%, rgba(3,7,7,0.3) 0%, rgba(3,7,7,0.97) 70%)",

          ease: "power1.inOut",
        },
        0.2
      );

      tl.to(
        heroRef.current,
        {
          scale: 0.5,
          borderRadius: "30px",

          boxShadow:
            "0 0 150px rgba(0,0,0,0.95)",

          ease: "power2.inOut",
        },
        0.3
      );


      /* =================================
         EVENT ANIMATIONS
      ================================= */

      eventCardsRef.current.forEach((card, index) => {
        if (!card) return;

        const images =
          card.querySelector(".event-images");

        const mainImage =
          card.querySelector(".event-main-image");

        const smallImage =
          card.querySelector(".event-small-image");

        const info =
          card.querySelector(".event-info");

        const number =
          card.querySelector(".event-number");

        gsap.from(images, {
          scrollTrigger: {
            trigger: card,
            start: "top 85%",
            end: "top 35%",
            scrub: 1,
          },

          y: 80,
          opacity: 0,
          scale: 0.94,

          ease: "none",
        });

        gsap.from(mainImage, {
          scrollTrigger: {
            trigger: card,
            start: "top 80%",
            end: "top 30%",
            scrub: 1,
          },

          scale: 1.12,

          ease: "none",
        });

        gsap.from(smallImage, {
          scrollTrigger: {
            trigger: card,
            start: "top 70%",
            end: "top 35%",
            scrub: 1,
          },

          x: index % 2 === 0 ? 80 : -80,
          y: 40,
          opacity: 0,
          rotation: index % 2 === 0 ? 5 : -5,

          ease: "none",
        });

        gsap.from(info, {
          scrollTrigger: {
            trigger: card,
            start: "top 65%",
            end: "top 40%",
            scrub: 1,
          },

          y: 50,
          opacity: 0,

          ease: "none",
        });

        gsap.from(number, {
          scrollTrigger: {
            trigger: card,
            start: "top 75%",
            end: "top 45%",
            scrub: 1,
          },

          x: index % 2 === 0 ? -30 : 30,
          opacity: 0,

          ease: "none",
        });
      });


      /* =================================
         RSVP REVEAL
      ================================= */

      gsap.from(".rsvp-content", {
        scrollTrigger: {
          trigger: ".rsvp-section",
          start: "top 75%",
        },

        y: 60,
        opacity: 0,
        duration: 1.2,
        ease: "power2.out",
      });

    });

    return () => ctx.revert();
  }, []);


  return (
    <div className="page">

      {/* =================================
          HERO
      ================================= */}

      <section
        className="hero"
        ref={heroRef}
      >

        <div
          className="forest-layer"
          ref={forestLayerRef}
        >
          <img
            src={forest}
            alt="Enchanted forest"
          />
        </div>

        <div
          className="glow"
          ref={glowRef}
        ></div>

        <div
          className="particles"
          ref={particlesRef}
        >
          <span>✦</span>
          <span>✦</span>
          <span>✦</span>
          <span>✦</span>
          <span>✦</span>
          <span>✦</span>
          <span>✦</span>
          <span>✦</span>
        </div>

        <div
          className="hero-overlay"
          ref={overlayRef}
        ></div>

        <div className="hero-content">

          <p>
            Some stories are written.
          </p>

          <p>
            Some are meant to be lived.
          </p>

          <div
            className="scroll-hint"
            ref={scrollHintRef}
          >
            <span>✦</span>

            <small>
              Scroll to enter
            </small>

            <span>✦</span>
          </div>

        </div>

      </section>


      {/* =================================
          STORY
      ================================= */}

      <section className="transition">

        <img
          src={storyBg}
          alt="Story background"
          className="story-bg"
        />

        <div className="transition-bg"></div>

        <div className="story-interface">

          <div className="story-progress">

            <span className="progress-label">
              01
            </span>

            <div className="progress-track">

              <div
                className="progress-fill"
                ref={progressFillRef}
              ></div>

            </div>

            <span className="progress-label">
              03
            </span>

          </div>


          <div className="story-top">

            <span>✦</span>

            <p>
              THE STORY
            </p>

            <span>✦</span>

          </div>


          <div className="story-card">

            <div className="card-corner top-left"></div>
            <div className="card-corner top-right"></div>
            <div className="card-corner bottom-left"></div>
            <div className="card-corner bottom-right"></div>

            <p className="story-number">
              01
            </p>

            <h1>
              The Beginning
              <br />
              of Forever
            </h1>

            <div className="gold-line"></div>

            <p className="story-copy">
              Somewhere between chance and fate,
              two paths crossed and a beautiful
              story began.
            </p>

            <p className="couple">
              AARAV
              <span>✦</span>
              MEERA
            </p>

            <div className="story-actions">

              <button className="story-btn">
                <span className="btn-text">
                  Discover Our Story
                </span>

                <span className="btn-arrow">
                  →
                </span>
              </button>

            </div>

          </div>


          <div className="story-scroll">

            <span></span>

            <small>
              Continue the journey
            </small>

          </div>

        </div>

      </section>


      {/* =================================
          EVENTS
      ================================= */}

      <section className="events-section">

        <div className="events-heading">

          <span>
            ✦ THE JOURNEY ✦
          </span>

          <h2>
            Three Moments,
            <br />
            One Beautiful Story
          </h2>

          <p>
            From laughter and rituals to the
            moment we said forever.
          </p>

        </div>


        {/* HALDI */}

        <div
          className="event-card"
          ref={(el) =>
            (eventCardsRef.current[0] = el)
          }
        >

          <div className="event-number">
            01
          </div>

          <div className="event-images">

            <img
              src={haldi1}
              alt="Haldi celebration"
              className="event-main-image"
            />

            <img
              src={haldi2}
              alt="Haldi memories"
              className="event-small-image"
            />

          </div>

          <div className="event-info">

            <span className="event-label">
              THE FIRST CELEBRATION
            </span>

            <h3>
              Haldi
            </h3>

            <div className="event-line"></div>

            <p>
              A day painted in yellow,
              filled with laughter, warmth
              and beautiful memories.
            </p>

          </div>

        </div>


        {/* WEDDING */}

        <div
          className="event-card reverse"
          ref={(el) =>
            (eventCardsRef.current[1] = el)
          }
        >

          <div className="event-number">
            02
          </div>

          <div className="event-images">

            <img
              src={wedding1}
              alt="Wedding celebration"
              className="event-main-image"
            />

            <img
              src={wedding2}
              alt="Wedding memories"
              className="event-small-image"
            />

          </div>

          <div className="event-info">

            <span className="event-label">
              THE DAY WE SAID YES
            </span>

            <h3>
              Wedding
            </h3>

            <div className="event-line"></div>

            <p>
              Two hearts, two journeys,
              and one promise to walk
              through life together.
            </p>

          </div>

        </div>


        {/* RECEPTION */}

        <div
          className="event-card"
          ref={(el) =>
            (eventCardsRef.current[2] = el)
          }
        >

          <div className="event-number">
            03
          </div>

          <div className="event-images">

            <img
              src={reception2}
              alt="Reception celebration"
              className="event-main-image"
            />

            <img
              src={reception3}
              alt="Reception memories"
              className="event-small-image"
            />

          </div>

          <div className="event-info">

            <span className="event-label">
              AN EVENING TO REMEMBER
            </span>

            <h3>
              Reception
            </h3>

            <div className="event-line"></div>

            <p>
              An evening of music,
              celebration and the people
              who made it unforgettable.
            </p>

          </div>

        </div>


        <div className="events-end">

          <span>✦</span>

          <p>
            THE STORY CONTINUES
          </p>

          <span>✦</span>

        </div>

      </section>


      {/* =================================
          RSVP
      ================================= */}

      <section className="rsvp-section">

        <div className="rsvp-glow"></div>

        <div className="rsvp-content">

          {!submitted ? (
            <>

              <span className="rsvp-label">
                ✦ A LITTLE NOTE ✦
              </span>

              <h2>
                Will you join us
                <br />
                for this chapter?
              </h2>

              <p className="rsvp-intro">
                Your presence would make our
                celebration even more magical.
              </p>


              <form
                className="rsvp-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  setSubmitted(true);
                }}
              >

                <div className="form-group">

                  <label>
                    Your Name
                  </label>

                  <input
                    type="text"
                    placeholder="Enter your name"
                    required
                  />

                </div>


                <div className="form-group">

                  <label>
                    Will you be joining us?
                  </label>

                  <div className="attendance-options">

                    <label className="choice">

                      <input
                        type="radio"
                        name="attendance"
                        value="yes"
                        required
                      />

                      <span>
                        Joyfully attending
                      </span>

                    </label>


                    <label className="choice">

                      <input
                        type="radio"
                        name="attendance"
                        value="no"
                      />

                      <span>
                        Sadly, can't make it
                      </span>

                    </label>

                  </div>

                </div>


                <div className="form-group">

                  <label>
                    Number of Guests
                  </label>

                  <select
                    defaultValue=""
                    required
                  >

                    <option
                      value=""
                      disabled
                    >
                      Select
                    </option>

                    <option value="1">
                      1 Guest
                    </option>

                    <option value="2">
                      2 Guests
                    </option>

                    <option value="3">
                      3 Guests
                    </option>

                    <option value="4">
                      4 Guests
                    </option>

                  </select>

                </div>


                <div className="form-group">

                  <label>
                    A little message
                  </label>

                  <textarea
                    placeholder="Leave us a wish..."
                    rows="4"
                  ></textarea>

                </div>


                <button
                  type="submit"
                  className="rsvp-button"
                >

                  <span>
                    Send Your Wishes
                  </span>

                  <b>
                    ✦
                  </b>

                </button>

              </form>

            </>
          ) : (

            /* SUCCESS MESSAGE */

            <div className="rsvp-success">

              <div className="success-star">
                ✦
              </div>

              <span>
                YOUR WISH HAS BEEN RECEIVED
              </span>

              <h2>
                Thank You
              </h2>

              <p>
                We can't wait to celebrate
                this beautiful day with you.
              </p>

              <div className="success-line"></div>

              <small>
                WITH LOVE, AARAV & MEERA
              </small>

            </div>

          )}

        </div>

      </section>

    </div>
  );
}

export default App;